# tickybot-assets
Asset files for the Tickybot Clone project
